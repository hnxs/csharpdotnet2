﻿/*Program: Rectangular.csstart
 *Author: Heather N. Smith
 *Date: April 13, 2016
 *Class: Prg205
 *This will allow a user to 
 *Enter height and width of 
 *A rectangle and output the
 *Area and perimeter
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG205Assignment2HeatherSmith
{
    class Rectangular
    {
        static void Main(string[] args)
        {
            //Declare Variables
            double height, width, area, perimeter;

            height = GetSize("Height");
            width = GetSize("Width");

            //Call Methods
            area = ComputeArea(height, width);
            perimeter = ComputePerimeter(height, width);
            DisplayResults(height, width, area, perimeter); 
            Console.ReadKey();
        }
        
        //Input Values
        public static double GetSize(string whichOne)
        {
            string inValue;
            double side;
            Console.Write("Enter the {0}: ", whichOne);
            inValue = Console.ReadLine();
            side = double.Parse(inValue);
            return side;
        }
        
        //Calculate Area
        public static double ComputeArea(double height, double width)
        {
            return height * width;
        }

        //Calculate perimeter
        public static double ComputePerimeter(double height, double width) 
        {
            return 2 * height + 2 * width;
        }
        
        //Display results
        public static void DisplayResults(double height, double width, double area, double perimeter)
        {
            Console.Clear();
            Console.WriteLine("Summary of Rectangular Measurements\n");
            Console.WriteLine("{0, -15} {1,5:f1}", "Height:", height);
            Console.WriteLine("{0, -15} {1,5:f1}", "Width:", width);
            Console.WriteLine("{0, -15} {1,5:f1}", "Area:", area);
            Console.WriteLine("{0, -15} {1,5:f1}", "Perimeter:", perimeter);              
        }
    }
}
